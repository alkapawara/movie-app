import React from 'react'

const CardModal = () => {
  return (
    <div>CardModal</div>
  )
}

export default CardModal